# Odoo + Meta WhatsApp Cloud API Webhook (Render-ready)

Este proyecto recibe mensajes entrantes desde **WhatsApp Cloud API (Meta)** y crea/actualiza un **Lead** en **Odoo Online CRM**.

## 1) Qué hace
- Endpoint GET `/webhook/meta` para verificación (hub.challenge)
- Endpoint POST `/webhook/meta` para eventos entrantes
- Crea/actualiza contacto (`res.partner`) por teléfono `+{wa_id}`
- Reutiliza el último lead abierto del contacto (si existe) o crea uno nuevo
- Registra el mensaje en el chatter del lead (`mail.message`)
- Evita duplicados usando `mail.message.message_id = msg.id`

## 2) Requisitos
- Node.js 18+
- Odoo Online con:
  - CRM activado
  - Usuario de integración con **API Key**
  - Equipo de ventas (ej. "Ventas WhatsApp") y su `team_id`
- Meta WhatsApp Cloud API:
  - App Business con producto WhatsApp
  - Webhook configurado a la URL pública de Render

## 3) Variables de entorno
Copia `.env.example` y completa los valores en Render -> Environment.

## 4) Deploy en Render
1. Sube este repositorio a GitHub.
2. Render -> New -> Web Service -> conecta el repo.
3. Build command: `npm install`
4. Start command: `npm start`
5. Agrega variables de entorno (ver `.env.example`)
6. Deploy.

Tu URL final será algo como:
`https://tu-servicio.onrender.com/webhook/meta`

## 5) Configurar Webhook en Meta
- Callback URL: `https://tu-servicio.onrender.com/webhook/meta`
- Verify token: igual a `META_VERIFY_TOKEN`
- Suscribe el evento: `messages`

## 6) Prueba
Envía un mensaje al número conectado a Cloud API.
En Odoo: CRM -> Pipeline (equipo "Ventas WhatsApp") debe aparecer un lead y en el chatter el mensaje.

## Notas
- Este ejemplo NO envía mensajes salientes. Eso se agrega después.
- Para adjuntos (imágenes, audio), se puede extender para descargar media desde Meta y adjuntarlo en Odoo.
